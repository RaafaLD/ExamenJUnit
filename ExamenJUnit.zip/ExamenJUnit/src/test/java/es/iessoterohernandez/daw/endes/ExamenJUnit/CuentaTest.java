package es.iessoterohernandez.daw.endes.ExamenJUnit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CuentaTest {
	
	static Cuenta c1;
	static Cuenta c2;
	
	@BeforeAll
	static void setUpBeforeClass1() throws Exception {
		c1 = new Cuenta("403455422344554","Darío Sarmiento García"); 
		c2 = new Cuenta("454335549499494","Manuel Domínguez Cejudo"); 
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		c1 = null;
		c2 = null;
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
