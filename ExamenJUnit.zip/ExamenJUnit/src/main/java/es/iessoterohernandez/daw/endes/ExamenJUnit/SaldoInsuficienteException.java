package es.iessoterohernandez.daw.endes.ExamenJUnit;

public class SaldoInsuficienteException extends Exception {
	
		public SaldoInsuficienteException(String message) {
			super(message);
		}
}
