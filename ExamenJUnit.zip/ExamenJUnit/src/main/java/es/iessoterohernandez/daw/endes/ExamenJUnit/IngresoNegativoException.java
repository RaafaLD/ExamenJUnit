package es.iessoterohernandez.daw.endes.ExamenJUnit;

public class IngresoNegativoException extends Exception{
	public IngresoNegativoException(String message) {
		super(message);
	}
}
